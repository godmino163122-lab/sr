const express = require("express");
const session = require("express-session");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const path = require("path");
require("dotenv").config?.();

const app = express();
const db = new Database(path.join(__dirname, "star-rackers.db"));
const PORT = process.env.PORT || 3000;

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE-ME-IN-PRODUCTION",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly:true, sameSite:"lax", secure:false, maxAge: 8*60*60*1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 role TEXT NOT NULL, name TEXT NOT NULL, email TEXT DEFAULT '',
 active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS content(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 type TEXT NOT NULL, title TEXT NOT NULL, body TEXT DEFAULT '',
 meta TEXT DEFAULT '{}', published INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS leads(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT DEFAULT '',
 phone TEXT DEFAULT '', company TEXT DEFAULT '', service TEXT DEFAULT '',
 budget TEXT DEFAULT '', deadline TEXT DEFAULT '', message TEXT DEFAULT '',
 status TEXT DEFAULT 'New', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS projects(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, client TEXT DEFAULT '',
 description TEXT DEFAULT '', status TEXT DEFAULT 'New', progress INTEGER DEFAULT 0,
 assigned_to INTEGER, deadline TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT DEFAULT '');
`);

function seedUsers(){
  const defaults = [
    ["starrackersadmin", process.env.SUPERADMIN_PASSWORD || "SR_Admin#7Kq!92","Super Admin","Star Rackers Admin"],
    ["starrackersdev", process.env.DEV_PASSWORD || "SR_Dev#4Mx!81","Developer","Star Rackers Developer"],
    ["starrackersdesign", process.env.DESIGN_PASSWORD || "SR_Design#9Tp!46","Designer","Star Rackers Designer"],
    ["starrackerssales", process.env.SALES_PASSWORD || "SR_Sales#6Vz!73","Sales","Star Rackers Sales"],
    ["starrackersfinance", process.env.FINANCE_PASSWORD || "SR_Finance#3Rq!58","Finance","Star Rackers Finance"]
  ];
  const insert=db.prepare("INSERT OR IGNORE INTO users(username,password_hash,role,name) VALUES(?,?,?,?)");
  for(const [u,p,r,n] of defaults) insert.run(u,bcrypt.hashSync(p,12),r,n);
}
seedUsers();

const roles = {
  "Super Admin":["*"],
  "Developer":["projects","content:portfolio"],
  "Designer":["content:portfolio","content:services"],
  "Sales":["leads","clients"],
  "Finance":["payments","invoices"],
  "Project Manager":["projects"],
  "Staff":["projects:assigned"]
};
function auth(req,res,next){
  if(!req.session.user) return res.status(401).json({error:"Unauthorized"});
  next();
}
function allow(permission){
  return (req,res,next)=>{
    if(req.session.user.role==="Super Admin") return next();
    const p=roles[req.session.user.role]||[];
    if(p.includes(permission)) return next();
    return res.status(403).json({error:"Forbidden"});
  }
}

app.post("/api/login",(req,res)=>{
  const {username,password}=req.body||{};
  const user=db.prepare("SELECT * FROM users WHERE username=? AND active=1").get(username);
  if(!user || !bcrypt.compareSync(password||"",user.password_hash)) return res.status(401).json({error:"Invalid username or password"});
  req.session.user={id:user.id,username:user.username,name:user.name,role:user.role};
  res.json(req.session.user);
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>res.json(req.session.user||null));

app.get("/api/public",(req,res)=>{
  const rows=db.prepare("SELECT * FROM content WHERE published=1 ORDER BY id DESC").all();
  const out={services:[],portfolio:[],pricing:[],testimonials:[],faq:[],pages:[]};
  for(const r of rows) (out[r.type]||out.pages).push(r);
  const settings=Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]));
  res.json({content:out,settings});
});

app.get("/api/admin/summary",auth,(req,res)=>{
  const count=t=>db.prepare(`SELECT COUNT(*) c FROM ${t}`).get().c;
  res.json({leads:count("leads"),projects:count("projects"),staff:count("users"),content:count("content")});
});

app.get("/api/content",auth,(req,res)=>res.json(db.prepare("SELECT * FROM content ORDER BY id DESC").all()));
app.post("/api/content",auth,allow("content:services"),(req,res)=>{
  const {type,title,body="",meta="{}",published=1}=req.body;
  if(!type||!title) return res.status(400).json({error:"Type and title required"});
  const r=db.prepare("INSERT INTO content(type,title,body,meta,published) VALUES(?,?,?,?,?)").run(type,title,body,typeof meta==="string"?meta:JSON.stringify(meta),published?1:0);
  res.json(db.prepare("SELECT * FROM content WHERE id=?").get(r.lastInsertRowid));
});
app.put("/api/content/:id",auth,(req,res)=>{
  const {title,body,meta,published}=req.body;
  db.prepare("UPDATE content SET title=COALESCE(?,title),body=COALESCE(?,body),meta=COALESCE(?,meta),published=COALESCE(?,published) WHERE id=?")
    .run(title,body,typeof meta==="object"?JSON.stringify(meta):meta,published==null?null:(published?1:0),req.params.id);
  res.json({ok:true});
});
app.delete("/api/content/:id",auth,(req,res)=>{
  db.prepare("DELETE FROM content WHERE id=?").run(req.params.id); res.json({ok:true});
});

app.get("/api/leads",auth,allow("leads"),(req,res)=>res.json(db.prepare("SELECT * FROM leads ORDER BY id DESC").all()));
app.post("/api/leads",(req,res)=>{
  const {name,email,phone,company,service,budget,deadline,message}=req.body;
  if(!name) return res.status(400).json({error:"Name required"});
  db.prepare("INSERT INTO leads(name,email,phone,company,service,budget,deadline,message) VALUES(?,?,?,?,?,?,?,?)")
    .run(name,email||"",phone||"",company||"",service||"",budget||"",deadline||"",message||"");
  res.json({ok:true});
});
app.put("/api/leads/:id",auth,allow("leads"),(req,res)=>{
  db.prepare("UPDATE leads SET status=? WHERE id=?").run(req.body.status,req.params.id); res.json({ok:true});
});

app.get("/api/projects",auth,allow("projects"),(req,res)=>res.json(db.prepare("SELECT p.*,u.name assigned_name FROM projects p LEFT JOIN users u ON u.id=p.assigned_to ORDER BY p.id DESC").all()));
app.post("/api/projects",auth,allow("projects"),(req,res)=>{
  const {name,client,description,status="New",progress=0,assigned_to=null,deadline=""}=req.body;
  const r=db.prepare("INSERT INTO projects(name,client,description,status,progress,assigned_to,deadline) VALUES(?,?,?,?,?,?,?)")
    .run(name,client||"",description||"",status,Number(progress)||0,assigned_to||null,deadline);
  res.json({id:r.lastInsertRowid});
});
app.put("/api/projects/:id",auth,allow("projects"),(req,res)=>{
  const {status,progress,assigned_to,deadline}=req.body;
  db.prepare("UPDATE projects SET status=COALESCE(?,status),progress=COALESCE(?,progress),assigned_to=COALESCE(?,assigned_to),deadline=COALESCE(?,deadline) WHERE id=?")
   .run(status,progress==null?null:Number(progress),assigned_to||null,deadline,req.params.id);
  res.json({ok:true});
});

app.get("/api/staff",auth,(req,res)=>{
  res.json(db.prepare("SELECT id,username,role,name,email,active,created_at FROM users ORDER BY id DESC").all());
});
app.post("/api/staff",auth,(req,res)=>{
  if(req.session.user.role!=="Super Admin") return res.status(403).json({error:"Super Admin only"});
  const {username,password,role,name,email=""}=req.body;
  if(!username||!password||!role||!name) return res.status(400).json({error:"Missing required fields"});
  try{
    const r=db.prepare("INSERT INTO users(username,password_hash,role,name,email) VALUES(?,?,?,?,?)")
      .run(username,bcrypt.hashSync(password,12),role,name,email);
    res.json({id:r.lastInsertRowid});
  }catch(e){res.status(400).json({error:"Username already exists"});}
});
app.put("/api/staff/:id",auth,(req,res)=>{
  if(req.session.user.role!=="Super Admin") return res.status(403).json({error:"Super Admin only"});
  const {name,email,role,active,password}=req.body;
  if(password) db.prepare("UPDATE users SET name=?,email=?,role=?,active=?,password_hash=? WHERE id=?")
    .run(name,email,role,active?1:0,bcrypt.hashSync(password,12),req.params.id);
  else db.prepare("UPDATE users SET name=?,email=?,role=?,active=? WHERE id=?").run(name,email,role,active?1:0,req.params.id);
  res.json({ok:true});
});

app.get("/api/settings",auth,(req,res)=>res.json(Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]))));
app.put("/api/settings",auth,(req,res)=>{
  const stmt=db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  const tx=db.transaction(obj=>{for(const [k,v] of Object.entries(obj)) stmt.run(k,String(v));}); tx(req.body||{});
  res.json({ok:true});
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Star Rackers running at http://localhost:${PORT}`));
