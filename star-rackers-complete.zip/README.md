# Star Rackers — Full-stack starter

A single Node.js + Express + SQLite application containing:
- Public agency website
- Database-backed CMS
- Admin login
- Role-based access
- Staff management
- Leads
- Projects
- Services
- Portfolio
- Pricing
- Testimonials
- FAQs
- Basic settings

## Run

1. Install Node.js 18+.
2. Copy `.env.example` to `.env` and change the secrets/passwords.
3. Run:
   npm install
   npm start
4. Open http://localhost:3000
5. Admin: http://localhost:3000/admin

## Initial accounts

The defaults are read from environment variables and hashed into SQLite on first run:
- starrackersadmin / SR_Admin#7Kq!92
- starrackersdev / SR_Dev#4Mx!81
- starrackersdesign / SR_Design#9Tp!46
- starrackerssales / SR_Sales#6Vz!73
- starrackersfinance / SR_Finance#3Rq!58

Change them before deployment.

## Important production hardening

Use HTTPS, a strong SESSION_SECRET, a managed database for larger deployments, secure cookie settings behind HTTPS, rate limiting, CSRF protection, validated file uploads, backups, audit logging, and a proper email/password-reset flow.
